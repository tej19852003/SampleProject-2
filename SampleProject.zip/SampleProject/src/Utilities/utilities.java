package Utilities;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class utilities {
	public static WebDriver driver = null;
	public static Properties PROPERTIES = new Properties();
	public static File PROPERTIES_FILEPATH = new File("..\\SampleProject\\Properties\\global-variables.properties");
	
	public static void loadGlobalLocators() throws Exception {
		PROPERTIES.load(new FileInputStream(PROPERTIES_FILEPATH));	
		Thread.sleep(2000);
	}	
	
	public static WebDriver Browser_setup(WebDriver driver, String name) throws Exception{
       if(name.equalsIgnoreCase("firefox")){
    	System.setProperty("webdriver.gecko.driver", utilities.PROPERTIES.getProperty("FirefoxDriverServerPath"));
           driver = new FirefoxDriver();
	    }
	    else if(name.equalsIgnoreCase("chrome")){
	    	System.setProperty("webdriver.chrome.driver", utilities.PROPERTIES.getProperty("ChromeDriverServerPath"));
	        driver = new ChromeDriver();
	    }
	    else if(name.equalsIgnoreCase("ie")){
	    	System.setProperty("webdriver.ie.driver", utilities.PROPERTIES.getProperty("IEDriverServerPath"));	
	    	driver = new InternetExplorerDriver();	
	    }
	    else{
	        System.out.println("Provided Browser detail is not correct, so using details Chrome Browser");
	        System.setProperty("webdriver.chrome.driver", utilities.PROPERTIES.getProperty("ChromeDriverServerPath"));
	        driver = new ChromeDriver();
	    }	    
    return driver;
	}
	public static void waitForPageLoad(WebDriver driver, By vxpath) throws Exception {
		for (int i=0; i<15 && driver.findElements(vxpath).size() == 0; i++) {
           Thread.sleep(1000);
        }
	}	
}
