package TestCases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;


import Utilities.utilities;



public class LaunchURL {
	WebDriver driver;
	SoftAssert softas = new SoftAssert();
	@BeforeSuite
	public void beforesuite() throws Exception{
		Reporter.log("beforesuite Execution Started");
		utilities.loadGlobalLocators();
		String myBrowser = utilities.PROPERTIES.getProperty("Browser");
		System.out.println("myBrowser="+myBrowser);
		driver = utilities.Browser_setup(driver, myBrowser);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(utilities.PROPERTIES.getProperty("QuickenURL"));
		Thread.sleep(3000);
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.quicken.com/budget-calculator");	
		Reporter.log("beforesuite Execution Completed"); 		
	}
	@Test(priority=1, description="Verify elements set1 are present")
	public void Verifyallelementsset1present() throws Exception{
		Reporter.log("Verifyallelementspresentset1 Execution Started");
		Assert.assertTrue(driver.findElement(By.xpath(".//*[@id='page-title']")).getText().trim().equals("Budget Calculator"));
		Assert.assertTrue(driver.findElement(By.xpath(".//*[@id='block-system-main']/div/section/div/header/div/div/div[1]/h1")).getText().trim().equals("Try our FREE budget calculator"));
		Reporter.log("Verifyallelementspresentset1 Execution Completed");
	}
	@Test(priority=2,description="Verify elements set2 are present", dependsOnMethods = { "Verifyallelementsset1present" })
	public void Verifyallelementsset2present() throws Exception {
		Reporter.log("Verifyallelementspresentset1 Execution Started");
		Thread.sleep(2000);
		Assert.assertTrue(driver.findElement(By.xpath(".//*[@id='step1']/div/form/input[1]")).isDisplayed());
		Assert.assertTrue(driver.findElement(By.xpath(".//*[@id='step1']/div/p[1]")).getText().trim().equals("Salary/Wages"));
		Thread.sleep(1000);
		Assert.assertTrue(driver.findElement(By.xpath(".//*[@id='step1']/div/form/input[2]")).isDisplayed());
		Assert.assertTrue(driver.findElement(By.xpath(".//*[@id='step1']/div/p[2]")).getText().trim().equals("Other Income"));
		Reporter.log("Verifyallelementspresentset1 Execution Completed");	
	}
	@Test(priority=3,description="Verify elements set3 are present", dependsOnMethods = { "Verifyallelementsset1present" })
	public void Verifyallelementsset3present() throws Exception {
		Reporter.log("Verifyallelementsset3present Execution Started");
		Thread.sleep(1000);
		Assert.assertTrue(driver.findElement(By.xpath("//table/tbody/tr[@class='underline']/th[1]/strong")).isDisplayed());
		Assert.assertTrue(driver.findElement(By.xpath("//table/tbody/tr[@class='underline']/th[1]/strong")).getText().trim().equals("Monthly Income"));
		Thread.sleep(1000);
		Assert.assertTrue(driver.findElement(By.xpath("//table/tbody/tr[7]/th[1]/strong")).isDisplayed());
		Assert.assertTrue(driver.findElement(By.xpath("//table/tbody/tr[7]/th[1]/strong")).getText().trim().equals("Monthly Expenses"));
		Reporter.log("Verifyallelementsset3present Execution Completed");	
	}
	@Test(priority=4,description="Supply Monthly Income datas", dependsOnMethods = { "Verifyallelementsset1present" })
	public void Supplymonthlyincomedatas() throws Exception {
		Reporter.log("Supplymonthlyincomedatas Execution Started");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id='step1']/div/form/input[1]")).clear();
		driver.findElement(By.xpath("//*[@id='step1']/div/form/input[1]")).sendKeys("5000");
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='step1']/div/form/input[2]")).clear();
		driver.findElement(By.xpath(".//*[@id='step1']/div/form/input[2]")).sendKeys("500");
		Thread.sleep(2000);
		driver.findElement(By.xpath(".//*[@id='step1']/a")).click();
		Thread.sleep(4000);
		Assert.assertTrue(driver.findElement(By.xpath(".//*[@id='step2']/h2")).getText().trim().equals("Housing Expenses"));
		Reporter.log("Supplymonthlyincomedatas Execution Completed");	
	}

	
	@AfterSuite
	public void After_suite() throws Exception{
		Reporter.log("After_suite Execution Started");
		driver.quit();
		Reporter.log("After_suite Execution Completed"); 		
	}
}
